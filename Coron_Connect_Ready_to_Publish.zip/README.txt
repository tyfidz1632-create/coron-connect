# Coron Connect — Free launch website

This is a ready-to-upload static website starter for Coron Connect.

## Included
- Responsive homepage
- Local marketplace category cards
- Digital Products section
- Links to Little Bloom Printables on Raket.PH
- Coron tourism inspiration section
- Marketplace search/filter
- Seller contact button (requires replacing email placeholder)

## Before publishing
1. Open `index.html` in a text editor.
2. Find `YOUR_EMAIL_HERE` and replace it with the email address where you want seller inquiries.
3. Confirm the Raket.PH links and listing details.
4. Do not advertise listings as available until the seller has confirmed them.

## Publish free with GitHub Pages
1. Create/sign in to GitHub.
2. Create a new public repository named `coron-connect`.
3. Upload `index.html` to the repository root (the top-level folder).
4. Open repository **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then Save.
7. Wait for GitHub Pages to show your website URL.

The exact URL is shown in GitHub Pages settings after publishing. This package does not publish itself.

## Current limitations
This is a static starter site. It does not yet include seller login, product database, cart, checkout, payment processing, or automatic digital-file delivery. Digital product buttons currently direct visitors to the seller's Raket.PH shop. A backend and payment/download integration would be needed for a full multi-vendor marketplace.
